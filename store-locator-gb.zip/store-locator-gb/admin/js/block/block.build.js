/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

var registerBlockType = wp.blocks.registerBlockType;
var _wp$element = wp.element,
    Fragment = _wp$element.Fragment,
    useState = _wp$element.useState;
var _wp$blockEditor = wp.blockEditor,
    InspectorControls = _wp$blockEditor.InspectorControls,
    MediaUpload = _wp$blockEditor.MediaUpload,
    MediaUploadCheck = _wp$blockEditor.MediaUploadCheck;
var _wp$components = wp.components,
    PanelBody = _wp$components.PanelBody,
    Button = _wp$components.Button,
    TextControl = _wp$components.TextControl,
    TextareaControl = _wp$components.TextareaControl,
    NumberControl = _wp$components.NumberControl;
var __ = wp.i18n.__;


registerBlockType('custom/store-locator', {
    title: __('Store Locator', 'store-locator'),
    icon: 'store',
    category: 'common',
    attributes: {
        stores: {
            type: 'array',
            default: []
        }
    },
    edit: function edit(_ref) {
        var attributes = _ref.attributes,
            setAttributes = _ref.setAttributes;
        var stores = attributes.stores;

        var allowedStoreTypes = ['General', 'Medical', 'Bar', 'Restaurant'];

        var addStore = function addStore() {
            var newStores = [].concat(_toConsumableArray(stores), [{ name: '', location: '', image: '', type: '', employees: 0, coordinates: '' }]);
            // console.log(newStores);
            setAttributes({ stores: newStores });
        };

        var updateStore = function updateStore(value, index, field) {
            var newStores = [].concat(_toConsumableArray(stores));
            newStores[index][field] = value;
            setAttributes({ stores: newStores });
        };

        var removeStore = function removeStore(index) {
            var newStores = [].concat(_toConsumableArray(stores));
            newStores.splice(index, 1);
            setAttributes({ stores: newStores });
        };

        var handleNumberChange = function handleNumberChange(value, index, field) {
            // Ensure the value is a number
            var numberValue = parseInt(value, 10);
            if (!isNaN(numberValue)) {
                updateStore(numberValue, index, field);
            }
        };

        var validateTypeOfStore = function validateTypeOfStore(value, index) {
            console.log(value);
            if (allowedStoreTypes.includes(value)) {
                updateStore(value, index, 'type');
            } else {
                alert(__('Invalid store type. Please enter one of the following: General, Medical, Bar, Restaurant', 'text-domain'));
            }
        };

        var validateLocation = function validateLocation(value, index) {
            var parts = value.split(',');
            if (parts.length === 3) {
                updateStore(value, index, 'location');
            } else {
                alert(__('Location must include city, state, and country, separated by commas.', 'text-domain'));
            }
        };

        var validateCoordinates = function validateCoordinates(value, index) {
            var parts = value.split(',');
            if (parts.length === 2) {
                var lat = parseFloat(parts[0].trim());
                var lon = parseFloat(parts[1].trim());
                if (!isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
                    updateStore(value, index, 'coordinates');
                } else {
                    alert(__('Coordinates must be valid latitude and longitude values.', 'text-domain'));
                }
            } else {
                alert(__('Coordinates must be in the format "latitude, longitude".', 'text-domain'));
            }
        };

        return wp.element.createElement(
            Fragment,
            null,
            stores.map(function (store, index) {
                return wp.element.createElement(
                    'div',
                    { key: index, className: 'store-item-editor' },
                    wp.element.createElement(TextControl, {
                        label: __('Store Name', 'store-locator'),
                        value: store.name,
                        onChange: function onChange(value) {
                            return updateStore(value, index, 'name');
                        }
                    }),
                    wp.element.createElement(TextControl, {
                        label: __('Location (City, State, Country)', 'text-domain'),
                        value: store.location,
                        onChange: function onChange(value) {
                            return updateStore(value, index, 'location');
                        },
                        onBlur: function onBlur(value) {
                            return validateLocation(store.location, index);
                        }
                    }),
                    wp.element.createElement(
                        MediaUploadCheck,
                        null,
                        wp.element.createElement(MediaUpload, {
                            onSelect: function onSelect(media) {
                                return updateStore(media.url, index, 'image');
                            },
                            allowedTypes: ['image'],
                            render: function render(_ref2) {
                                var open = _ref2.open;
                                return wp.element.createElement(
                                    Button,
                                    { onClick: open, isDefault: true, isLarge: true },
                                    store.image ? __('Change Image', 'store-locator') : __('Upload Image', 'store-locator')
                                );
                            }
                        })
                    ),
                    store.image && wp.element.createElement('img', { src: store.image, alt: '', style: { maxWidth: '100%' } }),
                    wp.element.createElement(TextControl, {
                        label: __('Type of Store', 'store-locator'),
                        value: store.type,
                        onChange: function onChange(value) {
                            return updateStore(value, index, 'type');
                        },
                        onBlur: function onBlur(value) {
                            return validateTypeOfStore(store.type, index);
                        }
                    }),
                    wp.element.createElement(TextControl, {
                        label: __('Number of Employees', 'store-locator'),
                        value: store.employees,
                        onChange: function onChange(value) {
                            return handleNumberChange(value, index, 'employees');
                        },
                        type: 'number'
                    }),
                    wp.element.createElement(TextControl, {
                        label: __('Global Coordinates', 'store-locator'),
                        value: store.coordinates,
                        onChange: function onChange(value) {
                            return updateStore(value, index, 'coordinates');
                        },
                        onBlur: function onBlur(value) {
                            return validateCoordinates(store.coordinates, index);
                        }
                    }),
                    wp.element.createElement(
                        Button,
                        { isDestructive: true, onClick: function onClick() {
                                return removeStore(index);
                            } },
                        __('Remove Store', 'store-locator')
                    ),
                    wp.element.createElement('hr', null)
                );
            }),
            wp.element.createElement(
                Button,
                { isPrimary: true, onClick: addStore },
                __('Add Store', 'store-locator')
            )
        );
    },
    save: function save() {
        return null;
    }
});

/***/ })
/******/ ]);
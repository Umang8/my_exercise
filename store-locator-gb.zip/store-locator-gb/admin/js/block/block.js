const { registerBlockType } = wp.blocks;
const { Fragment, useState } = wp.element;
const { InspectorControls, MediaUpload, MediaUploadCheck } = wp.blockEditor;
const { PanelBody, Button, TextControl, TextareaControl, NumberControl } = wp.components;
const { __ } = wp.i18n;

registerBlockType('custom/store-locator', {
    title: __('Store Locator', 'store-locator'),
    icon: 'store',
    category: 'common',
    attributes: {
        stores: {
            type: 'array',
            default: [],
        },
    },
    edit: ({ attributes, setAttributes }) => {
        const { stores } = attributes;
        const allowedStoreTypes = ['General', 'Medical', 'Bar', 'Restaurant'];

        const addStore = () => {
            const newStores = [...stores, { name: '', location: '', image: '', type: '', employees: 0, coordinates: '' }];
            // console.log(newStores);
            setAttributes({ stores: newStores });
        };

        const updateStore = (value, index, field) => {
            const newStores = [...stores];
            newStores[index][field] = value;
            setAttributes({ stores: newStores });
        };

        const removeStore = (index) => {
            const newStores = [...stores];
            newStores.splice(index, 1);
            setAttributes({ stores: newStores });
        };

        const handleNumberChange = (value, index, field) => {
            // Ensure the value is a number
            const numberValue = parseInt(value, 10);
            if (!isNaN(numberValue)) {
                updateStore(numberValue, index, field);
            }
        };

        const validateTypeOfStore = (value, index) => {
            console.log(value);
            if (allowedStoreTypes.includes(value)) {
                updateStore(value, index, 'type');
            } else {
                alert(__('Invalid store type. Please enter one of the following: General, Medical, Bar, Restaurant', 'text-domain'));
            }
        };

        const validateLocation = (value, index) => {
            const parts = value.split(',');
            if (parts.length === 3) {
                updateStore(value, index, 'location');
            } else {
                alert(__('Location must include city, state, and country, separated by commas.', 'text-domain'));
            }
        };

        const validateCoordinates = (value, index) => {
            const parts = value.split(',');
            if (parts.length === 2) {
                const lat = parseFloat(parts[0].trim());
                const lon = parseFloat(parts[1].trim());
                if (!isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
                    updateStore(value, index, 'coordinates');
                } else {
                    alert(__('Coordinates must be valid latitude and longitude values.', 'text-domain'));
                }
            } else {
                alert(__('Coordinates must be in the format "latitude, longitude".', 'text-domain'));
            }
        };

        return (
            
        <Fragment>
            {stores.map((store, index) => (  
                <div key={index} className="store-item-editor">
                    <TextControl
                        label={__('Store Name', 'store-locator')}
                        value={store.name}
                        onChange={(value) => updateStore(value, index, 'name')}
                    />
                    <TextControl
                        label={__('Location (City, State, Country)', 'text-domain')}
                        value={store.location}
                        onChange={(value) => updateStore(value, index, 'location')}
                        onBlur={(value) => validateLocation(store.location, index)}
                    />
                    <MediaUploadCheck>
                        <MediaUpload
                            onSelect={(media) => updateStore(media.url, index, 'image')}
                            allowedTypes={['image']}
                            render={({ open }) => (
                                <Button onClick={open} isDefault isLarge>
                                    {store.image ? __('Change Image', 'store-locator') : __('Upload Image', 'store-locator')}
                                </Button>
                            )}
                        />
                    </MediaUploadCheck>
                    {store.image && <img src={store.image} alt="" style={{ maxWidth: '100%' }} />}
                    <TextControl
                        label={__('Type of Store', 'store-locator')}
                        value={store.type}
                        onChange={(value) => updateStore(value, index, 'type')}
                        onBlur={(value) => validateTypeOfStore(store.type, index)}
                    />
                    <TextControl
                        label={__('Number of Employees', 'store-locator')}
                        value={store.employees}
                        onChange={(value) => handleNumberChange(value, index, 'employees')}
                        type="number"
                    />
                    <TextControl
                        label={__('Global Coordinates', 'store-locator')}
                        value={store.coordinates}
                        onChange={(value) => updateStore(value, index, 'coordinates')}
                        onBlur={(value) => validateCoordinates(store.coordinates, index)}
                    />
                    <Button isDestructive onClick={() => removeStore(index)}>
                        {__('Remove Store', 'store-locator')}
                    </Button>
                    <hr />
                </div>
            ))}
            <Button isPrimary onClick={addStore}>{__('Add Store', 'store-locator')}</Button>
        </Fragment>
        );
    },
    save: () => null,
});

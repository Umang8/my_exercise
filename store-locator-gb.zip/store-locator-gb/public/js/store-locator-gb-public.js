(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 */

	$(document).on('input', '#store-search-name', function() {
		var inpName = $(this).val().toLowerCase();
        $('.store-item').each(function() {
            var storeName = $(this).find('h3').data('name').toLowerCase();
            if (storeName.includes(inpName)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
	});

	$(document).on('input', '#store-search-location', function() {
		var inpLoc = $(this).val().toLowerCase();
        $('.store-item').each(function() {
            var storeName = $(this).find('p').data('location').toLowerCase();
            if (storeName.includes(inpLoc)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
	});

	$(document).on('input', '#store-search-type', function() {
		var inpType = $(this).val().toLowerCase();
        $('.store-item').each(function() {
            var storeName = $(this).find('#dType').data('typ').toLowerCase();
			console.log(storeName);
            if (storeName.includes(inpType)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
	});

})( jQuery );

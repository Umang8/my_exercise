<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.test.com
 * @since      1.0.0
 *
 * @package    Store_Locator_Gb
 * @subpackage Store_Locator_Gb/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Store_Locator_Gb
 * @subpackage Store_Locator_Gb/includes
 * @author     Umang <umangbhanvadia8@gmail.com>
 */
class Store_Locator_Gb_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
